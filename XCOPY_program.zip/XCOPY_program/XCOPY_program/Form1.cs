﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using XCOPY_program.Properties;

namespace XCOPY_program
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Path_Name_TextChanged(object sender, EventArgs e)
        {

        }

        static void initiate_XCOPY(string source, string dest) {
            string xcopy = "/C xcopy \"" + source + "\"" + " " + dest + "/s /i /y";
            Process.Start("cmd.exe", xcopy);
        }

        private void startXCOPY_Click(object sender, EventArgs e)
        {
            if (Path_Name.Text != "")
            {
                this.WindowState = FormWindowState.Minimized;

                if (location.Text.Contains(Settings.Default["L1"].ToString()))
                    initiate_XCOPY(@Path_Name.Text,@Settings.Default["DirLoc1"].ToString());

                else if(location.Text.Contains(Settings.Default["L2"].ToString()))
                    initiate_XCOPY(@Path_Name.Text, @Settings.Default["DirLoc2"].ToString());

                else if (location.Text.Contains(Settings.Default["L3"].ToString()))
                    initiate_XCOPY(@Path_Name.Text, @Settings.Default["DirLoc3"].ToString());

                else if (location.Text.Contains(Settings.Default["L4"].ToString()))
                    initiate_XCOPY(@Path_Name.Text, @Settings.Default["DirLoc4"].ToString());

                else if (location.Text.Contains(Settings.Default["L5"].ToString()))
                    initiate_XCOPY(@Path_Name.Text, @Settings.Default["DirLoc5"].ToString());

                else if (location.Text.Contains(Settings.Default["L6"].ToString()))
                    initiate_XCOPY(@Path_Name.Text, @Settings.Default["DirLoc6"].ToString());

                else
                    MessageBox.Show("Invalid. Start over.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
            }
            else { MessageBox.Show("Missing pathname. Try again.", "Error", MessageBoxButtons.OK, 
                   MessageBoxIcon.Error); }             
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            location.Items.RemoveAt(0); location.Items.Insert(0, Settings.Default["L1"]);
            location.Items.RemoveAt(1); location.Items.Insert(1, Settings.Default["L2"]);
            location.Items.RemoveAt(2); location.Items.Insert(2, Settings.Default["L3"]);
            location.Items.RemoveAt(3); location.Items.Insert(3, Settings.Default["L4"]);
            location.Items.RemoveAt(4); location.Items.Insert(4, Settings.Default["L5"]);
            location.Items.RemoveAt(5); location.Items.Insert(5, Settings.Default["L6"]);
        }

        private void configurationsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void location_SelectedIndexChanged(object sender, EventArgs e)
        {
 
        }

        private void aboutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.ShowDialog();
        }

        private void configurationsToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.ShowDialog();
        }
    }
}