﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using XCOPY_program.Properties;

namespace XCOPY_program
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Settings.Default["L1"] = textBox1.Text; Settings.Default["DirLoc1"] = textBox2.Text;
            Settings.Default["L2"] = textBox4.Text; Settings.Default["DirLoc2"] = textBox3.Text;
            Settings.Default["L3"] = textBox6.Text; Settings.Default["DirLoc3"] = textBox5.Text;
            Settings.Default["L4"] = textBox8.Text; Settings.Default["DirLoc4"] = textBox7.Text;
            Settings.Default["L5"] = textBox10.Text; Settings.Default["DirLoc5"] = textBox9.Text;
            Settings.Default["L6"] = textBox12.Text; Settings.Default["DirLoc6"] = textBox11.Text;

            Settings.Default.Save();
            this.Close(); Application.Restart();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            textBox1.Text = Settings.Default["L1"].ToString(); textBox2.Text = Settings.Default["DirLoc1"].ToString();
            textBox4.Text = Settings.Default["L2"].ToString(); textBox3.Text = Settings.Default["DirLoc2"].ToString();
            textBox6.Text = Settings.Default["L3"].ToString(); textBox5.Text = Settings.Default["DirLoc3"].ToString();
            textBox8.Text = Settings.Default["L4"].ToString(); textBox7.Text = Settings.Default["DirLoc4"].ToString();
            textBox10.Text = Settings.Default["L5"].ToString(); textBox9.Text = Settings.Default["DirLoc5"].ToString();
            textBox12.Text = Settings.Default["L6"].ToString(); textBox11.Text = Settings.Default["DirLoc6"].ToString();
            textBox1.Select(textBox1.Text.Length,0);
        }
    }
}
